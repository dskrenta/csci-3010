#include <vector>

#include "Tree.h"

// Names: David Skrenta

// no trees to begin with
int Tree::number_seeds_ = 0;

// Num instances to begin with
int Tree::number_instances_ = 0;
